const voiceAssistent = require('./node_modules/voice-assistent-js/src/Handler').Handler

class Test {
  test () {
    return new Promise(function (resolve) {
      resolve('test')
    })
  }
}

const mapping = {
  'test': Test
}

exports.handler = function (event, context, callback) {
  console.log(JSON.stringify(event), JSON.stringify(context));
  voiceAssistent.googleHome(mapping, event, context, callback)
}
